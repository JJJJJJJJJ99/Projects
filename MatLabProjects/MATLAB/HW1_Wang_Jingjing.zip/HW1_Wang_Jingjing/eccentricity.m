function y = eccentricity(a, b)
y = sqrt(1 - (b^2)/(a^2));
end