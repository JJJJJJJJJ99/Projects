%{
Author:Jingjing Wang
Date: Feb 11
This script determins which method is using a switch statement or using a
nested if-else.
%}

n = 100;
tic

switch n
    case 0
        n = 0;
    case 1
        n = 0;
    case 2
        n = 0;
    case 3
        n = 0;
    case 4
        n = 0;
    case 5
        n = 0;
    case 6
        n = 0;
    case 7
        n = 0;
    case 8
        n = 0;
    case 9
        n = 0;
    case 10
        n = 0;
    case 11
        n = 0;
    case 12
        n = 0;
    case 13
        n = 0;
    case 14
        n = 0;
    case 15
        n = 0;
    case 16
        n = 0;
    case 26
        n = 0;
    case 36
        n = 0;
    case 46
        n = 0;
    case 56
        n = 0;
    case 66
        n = 0;
    case 76
        n = 0;
    case 86
        n = 0;
    case 96
        n = 0;
    case 106
        n = 0;
    case 116
        n = 0;
    case 126
        n = 0;
    case 136
        n = 0;
    case 146
        n = 0;
    case 156
        n = 0;
    case 17
        n = 0;
    case 27
        n = 0;
    case 37
        n = 0;
    case 47
        n = 0;
    case 57
        n = 0;
    case 67
        n = 0;
    case 77
        n = 0;
    case 87
        n = 0;
    case 97
        n = 0;
    case 107
        n = 0;
    case 117
        n = 0;
    case 127
        n = 0;
    case 137
        n = 0;
    case 147
        n = 0;
    case 157
        n = 0;
    case 18
        n = 0;
    case 28
        n = 0;
    case 38
        n = 0;
    case 48
        n = 0;
    case 58
        n = 0;
    case 68
        n = 0;
    case 78
        n = 0;
    case 88
        n = 0;
    case 98
        n = 0;
    case 108
        n = 0;
    case 118
        n = 0;
    case 128
        n = 0;
    case 138
        n = 0;
    case 148
        n = 0;
    case 158
        n = 0;
    case 19
        n = 0;
    case 29
        n = 0;
    case 39
        n = 0;
    case 49
        n = 0;
    case 59
        n = 0;
    case 69
        n = 0;
    case 79
        n = 0;
    case 89
        n = 0;
    case 99
        n = 0;
    case 109
        n = 0;
    case 119
        n = 0;
    case 129
        n = 0;
    case 139
        n = 0;
    case 149
        n = 0;
    case 159
        n = 0;
end

timeSwitch = toc;

tic

if n == 0
    n = 0;
elseif n == 1
    n = 0;
elseif n == 2
    n = 0;
elseif n == 3
    n = 0;
elseif n == 4
    n = 0;
elseif n == 5
    n = 0;
elseif n == 6
    n = 0;
elseif n == 7
    n = 0;
elseif n == 8
    n = 0;
elseif n == 9
    n = 0;
elseif n == 10
    n = 0;
elseif n == 11
    n = 0;
elseif n == 12
    n = 0;
elseif n == 13
    n = 0;
elseif n == 14
    n = 0;
elseif n == 15
    n = 0;
elseif n == 16
    n = 0;
elseif n == 26
    n = 0;
elseif n == 36
    n = 0;
elseif n == 46
    n = 0;
elseif n == 56
    n = 0;
elseif n == 66
    n = 0;
elseif n == 76
    n = 0;
elseif n == 86
    n = 0;
elseif n == 96
    n = 0;
elseif n == 106
    n = 0;
elseif n == 116
    n = 0;
elseif n == 126
    n = 0;
elseif n == 136
    n = 0;
elseif n == 146
    n = 0;
elseif n == 156
    n = 0;
elseif n == 17
    n = 0;
elseif n == 27
    n = 0;
elseif n == 37
    n = 0;
elseif n == 47
    n = 0;
elseif n == 57
    n = 0;
elseif n == 67
    n = 0;
elseif n == 77
    n = 0;
elseif n == 87
    n = 0;
elseif n == 97
    n = 0;
elseif n == 107
    n = 0;
elseif n == 117
    n = 0;
elseif n == 127
    n = 0;
elseif n == 137
    n = 0;
elseif n == 147
    n = 0;
elseif n == 157
    n = 0;
elseif n == 18
    n = 0;
elseif n == 28
    n = 0;
elseif n == 38
    n = 0;
elseif n == 48
    n = 0;
elseif n == 58
    n = 0;
elseif n == 68
    n = 0;
elseif n == 78
    n = 0;
elseif n == 88
    n = 0;
elseif n == 98
    n = 0;
elseif n == 108
    n = 0;
elseif n == 118
    n = 0;
elseif n == 128
    n = 0;
elseif n == 138
    n = 0;
elseif n == 148
    n = 0;
elseif n == 158
    n = 0;
elseif n == 19
    n = 0;
elseif n == 29
    n = 0;
elseif n == 39
    n = 0;
elseif n == 49
    n = 0;
elseif n == 59
    n = 0;
elseif n == 69
    n = 0;
elseif n == 79
    n = 0;
elseif n == 89
    n = 0;
elseif n == 99
    n = 0;
elseif n == 109
    n = 0;
elseif n == 119
    n = 0;
elseif n == 129
    n = 0;
elseif n == 139
    n = 0;
elseif n == 149
    n = 0;
elseif n == 159
    n = 0;
end

timeIf = toc;

X = sprintf('Time for switch statement with 75 cases is %f.', timeSwitch);
disp(X);
Y = sprintf('Time for if statement with 75 cases is %f', timeIf);
disp(Y);


if timeSwitch < timeIf
    disp('It is faster using a switch statement.');
else 
    disp('It is faster using a nested if-else statement.');
end
  

Z = ('After a large amount of testings, the time needed for switch statement and if-else statement is qiute close. For the most of time, if-else statement is faster. But there some times switch statement won.');
disp(Z);
    
