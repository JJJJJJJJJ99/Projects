function [BW,maskedRGBImage] = createLogoMask(RGB)
